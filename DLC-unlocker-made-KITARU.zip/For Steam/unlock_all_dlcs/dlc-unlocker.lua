function WinSteamDLCManager:_check_dlc_data(dlc_data)
    for dlc_name, dlc_data in pairs(Global.dlc_manager.all_dlc_data) do
        dlc_data.verified = true
    end
end